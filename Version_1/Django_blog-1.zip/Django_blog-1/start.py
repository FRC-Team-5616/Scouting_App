import os
import socket
hostname = socket.gethostname()
ip_address = socket.gethostbyname(hostname)
port = 7065
print(f"http://{ip_address}:8000")
os.system("python manage.py runserver 0.0.0.0:8000")
